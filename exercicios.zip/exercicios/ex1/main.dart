import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color.fromARGB(255, 66, 183, 58),
        ),
        useMaterial3: true,
      ),
      home: const Home(),
    );
  }
}

class Home extends StatelessWidget {
  const Home({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 66, 198, 136),
        title: const Text("Lista de Filmes"),
      ),
      body: ListView(
        children: [
          Filme("Harry Potter: O Prisioneiro de Azkaban", "assets/images/harrypotter.jpg", 2004),
          Divider(),
          Filme("Avatar", "assets/images/avatar.jpg", 2009),
          Divider(),
          Filme("Um Olhar do Paraiso", "assets/images/umolhar.jpg", 2009),
          Divider(),
          Filme("The Ballad Of Songbirds And Snakes", "assets/images/jogos-vorazes.jpg", 2023),
          Divider(),
        ],
      ),
    );
  }
}

class Filme extends StatelessWidget {
  final String titulo;
  final String imagem;
  final int ano;

  Filme(this.titulo, this.imagem, this.ano, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          titulo,
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),textAlign: TextAlign.center,
        ),
        Container(
          width: 300,
          height: 250,
          child: Image.asset(
            imagem,
            fit: BoxFit.fill,
          ),
        ),
        Text(
          "Ano: $ano",
          style: TextStyle(fontSize: 20),
          textAlign: TextAlign.center,
        ),
        ElevatedButton(
          onPressed: () {
           print('Assistir: $titulo');
          },
          child: Text('Assistir'),
        ),
        Divider(), 
      ],
    );
  }
}
