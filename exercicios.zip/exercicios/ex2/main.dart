import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.black,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color.fromARGB(255, 66, 183, 58),
        ),
        useMaterial3: true,
      ),
      home: const Home(),
    );
  }
}

class Home extends StatelessWidget {
  const Home({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: const Text(
          "Spotify",
          style: TextStyle(color: Colors.white), 
        ),
        centerTitle: true, 
      ),
      body: ListView(
        children: [
          Musica("Sky", "assets/images/playboi.jpg", 2022),
          SizedBox(height: 16),
          Musica("Snooze", "assets/images/sos.jpg", 2022),
          SizedBox(height: 16),
          Musica("Cachorraz Kamikaze", "assets/images/rouff.jpg", 2022),
          SizedBox(height: 16),
          Musica("Mãe Natureza", "assets/images/sedex.jpg", 2023),
          SizedBox(height: 16),
        ],
      ),
    );
  }
}

class Musica extends StatelessWidget {
  final String titulo;
  final String imagem;
  final int ano;

  Musica(this.titulo, this.imagem, this.ano, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          titulo,
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold,
            color: const Color.fromARGB(255, 255, 255, 255),
          ),
          textAlign: TextAlign.center,
        ),
        Container(
          width: 300,
          height: 250,
          child: Image.asset(
            imagem,
            fit: BoxFit.fill,
          ),
        ),
        Text(
          "Ano: $ano",
          style: TextStyle(fontSize: 20, color: Colors.white),
          textAlign: TextAlign.center,
        ),
        ElevatedButton(
          onPressed: () {
            print('Ouvir Agora: $titulo');
          },
          child: Text('Ouvir Agora'),
        ),
        SizedBox(height: 16),
      ],
    );
  }
}
