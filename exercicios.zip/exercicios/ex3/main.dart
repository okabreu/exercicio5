import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        scaffoldBackgroundColor: Color.fromARGB(255, 255, 255, 255),
        colorScheme: ColorScheme.fromSeed(
          seedColor: Color.fromARGB(255, 46, 0, 0)     ),
        useMaterial3: true,
      ),
      home: const Home(),
    );
  }
}

class Home extends StatelessWidget {
  const Home({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 128, 2, 2),      
        title: const Text(
          "Portal do Aluno",
          style: TextStyle(color: Colors.white), 
        ),
        centerTitle: true, 
      ),
      body: ListView(
        children: [
          Materias("Matemática", "assets/images/matematica.jpg", 2023),
          Divider(),
          Materias("História", "assets/images/historia.jpg", 2023),
          Divider(),
          Materias("Biologia", "assets/images/biologia.jpg", 2023),
          Divider(),
          Materias("Português", "assets/images/portugues.jpg", 2023),
          Divider(),
        ],
      ),
    );
  }
}

class Materias extends StatelessWidget {
  final String titulo;
  final String imagem;
  final int ano;

  Materias(this.titulo, this.imagem, this.ano, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          titulo,
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold,
            color: Color.fromARGB(255, 0, 0, 0), 
          ),
          textAlign: TextAlign.center,
        ),
        Container(
          width: 300,
          height: 250,
          child: Image.asset(
            imagem,
            fit: BoxFit.fill,
          ),
        ),
        Text(
          "Ano: $ano",
          style: TextStyle(fontSize: 20, color: const Color.fromARGB(255, 0, 0, 0)), 
          textAlign: TextAlign.center,
        ),
        ElevatedButton(
          onPressed: () {
            print('Acessar: $titulo');
          },
          child: Text('Acessar conteúdo'),
        ),
        Divider(),
      ],
    );
  }
}
